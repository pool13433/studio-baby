<?php include './inc_header.php';?>
<tr>
    <td style="width:20%;vertical-align: text-top"><?php include './inc_menuleft.php';?></td>
    <td style="vertical-align: text-top">
        <fieldset>
            <legend>แพ็กเกตรูปภาพโปรโมชั่น</legend>
        </fieldset>
    </td>
</tr>
<?php include './inc_footer.php';?>